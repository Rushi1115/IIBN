from setuptools import setup

setup(
    name='flask',
    version='',
    packages=[''],
    url='',
    license='',
    author='aishw',
    author_email='',
    description=''
)
